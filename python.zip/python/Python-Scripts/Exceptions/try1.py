number = int(input("Enter a number: "))
result = 10 / number
print(f"The result is: {result}.")

print("This program ends here.")
print("Happy coding.")

