from modern import *

order_food("Pizza")
vac_feedback(efficacy=34, vac="Unknown")
time_activity(10, 20, 10, hobby="Dance", sport="Boxing", fun="Driving", work="DevOps")